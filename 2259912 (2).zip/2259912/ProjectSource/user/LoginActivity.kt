package com.example.atomicapp.user

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.example.atomicapp.R
import com.example.atomicapp.ui.dashboard.DashboardActivity

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val etName = findViewById<EditText>(R.id.etUsername)
        val btnLogin = findViewById<Button>(R.id.btnLogin)

        btnLogin.setOnClickListener {
            val username = etName.text.toString().trim()

            if (username.isNotEmpty()) {
                saveCurrentUserName(username)
                startActivity(Intent(this, DashboardActivity::class.java))
                finish()
            }
        }
    }
}
