package com.example.atomicapp.ui.progress

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.atomicapp.R

class DayStatsAdapter(private val items: List<DayStat>) :
    RecyclerView.Adapter<DayStatsAdapter.DayStatViewHolder>() {

    class DayStatViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvDate: TextView = view.findViewById(R.id.tvDate)
        val tvCompletedHabits: TextView = view.findViewById(R.id.tvCompletedHabits)
        val tvMood: TextView = view.findViewById(R.id.tvMood)
        val tvNote: TextView = view.findViewById(R.id.tvNote)
        val tvWalk: TextView = view.findViewById(R.id.tvWalk)
        val tvCO2: TextView = view.findViewById(R.id.tvCO2)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DayStatViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_day_stat, parent, false)
        return DayStatViewHolder(view)
    }

    override fun onBindViewHolder(holder: DayStatViewHolder, position: Int) {
        val item = items[position]

        holder.tvDate.text = item.date
        holder.tvCompletedHabits.text = "Completed habits: ${item.completedHabits}"
        holder.tvMood.text = "Mood: ${item.mood}"
        holder.tvNote.text = item.note
        holder.tvWalk.text = item.walkSummary
        holder.tvCO2.text = "CO₂ Saved: ${item.co2Saved} g"
    }


    override fun getItemCount(): Int = items.size
}
