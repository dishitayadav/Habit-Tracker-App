package com.example.atomicapp.user

import android.content.Context

fun Context.getCurrentUserName(): String {
    val prefs = getSharedPreferences("user_session", Context.MODE_PRIVATE)
    return prefs.getString("current_user", "Guest") ?: "Guest"
}
