package com.example.atomicapp.ui.progress

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.atomicapp.R
import java.text.SimpleDateFormat
import java.util.*

class DailyReflectionActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.Theme_AtomicApp)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_daily_reflection)

        val seekMood = findViewById<SeekBar>(R.id.seekMood)
        val tvEmoji = findViewById<TextView>(R.id.tvMoodEmoji)
        val etNote = findViewById<EditText>(R.id.etReflection)
        val saveButton = findViewById<Button>(R.id.btnSaveReflection)

        val emojis = listOf("😢", "☹️", "😐", "🙂", "😁")
        tvEmoji.text = emojis[2]

        seekMood.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                tvEmoji.text = emojis[progress]
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        saveButton.setOnClickListener {
            val mood = seekMood.progress + 1
            val note = etNote.text.toString()

            saveReflection(mood, note)
            finish()
        }
    }

    // saves mood data for the current user + date

    private fun saveReflection(mood: Int, note: String) {
        val prefs = getSharedPreferences("daily_stats", MODE_PRIVATE)

        val today = SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date())

        prefs.edit()
            .putInt("${today}_mood", mood)
            .putString("${today}_note", note)
            .apply()
    }
}
