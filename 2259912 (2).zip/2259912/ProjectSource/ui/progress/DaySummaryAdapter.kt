package com.example.atomicapp.ui.progress

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.atomicapp.R

class DaySummaryAdapter(private val list: List<DaySummary>) :
    RecyclerView.Adapter<DaySummaryAdapter.SummaryViewHolder>() {

    inner class SummaryViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvDate: TextView = view.findViewById(R.id.tvProgressDate)
        val tvHabits: TextView = view.findViewById(R.id.tvProgressHabits)
        val tvDistance: TextView = view.findViewById(R.id.tvProgressDistance)
        val tvCO2: TextView = view.findViewById(R.id.tvProgressCO2)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SummaryViewHolder {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_progress_day, parent, false)
        return SummaryViewHolder(v)
    }

    override fun onBindViewHolder(holder: SummaryViewHolder, position: Int) {
        val item = list[position]

        holder.tvDate.text = item.date
        holder.tvHabits.text = "Habits completed: ${item.habitsDone}"
        holder.tvDistance.text = "Distance: %.2f km".format(item.distanceKm)
        holder.tvCO2.text = "CO₂ saved: ${item.co2} g"
    }

    override fun getItemCount(): Int = list.size
}
