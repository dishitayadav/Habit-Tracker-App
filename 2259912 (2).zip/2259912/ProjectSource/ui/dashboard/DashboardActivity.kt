package com.example.atomicapp.ui.dashboard

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.atomicapp.MainActivity
import com.example.atomicapp.R
import com.example.atomicapp.notifications.ReminderReceiver
import com.example.atomicapp.ui.history.HistoryActivity
import com.example.atomicapp.ui.mood.MoodActivity
import com.example.atomicapp.ui.mood.MoodJournalActivity
import com.example.atomicapp.ui.progress.DailyReflectionActivity
import com.example.atomicapp.ui.progress.ProgressActivity
import com.example.atomicapp.ui.steps.StepTrackerActivity
import com.example.atomicapp.walk.WalkTrackerActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButton
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.util.Calendar
import com.example.atomicapp.user.getCurrentUserName

class DashboardActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.Theme_AtomicApp)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // toolbar
        val toolbar = findViewById<MaterialToolbar>(R.id.topAppBarDashboard)
        findViewById<MaterialButton>(R.id.btnMoodJournal).setOnClickListener {
            startActivity(Intent(this, MoodJournalActivity::class.java))
        }

        // showing username instead of a static title
        val username = getCurrentUserName()
        toolbar.title = "welcome back, $username 🌿"

        // ui references
        val subtitle = findViewById<TextView>(R.id.tvSubtitle)
        val steps = findViewById<TextView>(R.id.tvDashboardSteps)
        val reminderTime = findViewById<TextView>(R.id.tvReminderTime)

        //  quick default text values
        subtitle.text = "small habits, big impact."
        steps.text = "9,428 steps"   // placeholder until real step tracking is linked

        loadReminderTime(reminderTime)
        loadDailyZenQuote()  // loads a new quote once per day

        // main dashboard buttons
        val todayHabitsButton = findViewById<MaterialButton>(R.id.btnTodayHabits)
        val stepsButton = findViewById<MaterialButton>(R.id.btnOpenWalkTracker)
        val walkTrackerButton = findViewById<MaterialButton>(R.id.btnOpenWalkTracker)
        val progressButton = findViewById<MaterialButton>(R.id.btnOpenProgress)
        val historyButton = findViewById<MaterialButton>(R.id.btnOpenHistory)
        val setReminderButton = findViewById<MaterialButton>(R.id.btnSetReminder)

        todayHabitsButton.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }
        stepsButton.setOnClickListener {
            startActivity(Intent(this, StepTrackerActivity::class.java))
        }
        walkTrackerButton.setOnClickListener {
            startActivity(Intent(this, WalkTrackerActivity::class.java))
        }
        progressButton.setOnClickListener {
            startActivity(Intent(this, ProgressActivity::class.java))
        }
        historyButton.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }

        setReminderButton.setOnClickListener {
            openReminderTimePicker(reminderTime)
        }

        // bottom navigation setup
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavMain)
        bottomNav.selectedItemId = R.id.nav_home

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> true
                R.id.nav_progress -> {
                    startActivity(Intent(this, ProgressActivity::class.java)); true
                }
                R.id.nav_history -> {
                    startActivity(Intent(this, HistoryActivity::class.java)); true
                }
                else -> false
            }
        }
    }

    //   zen quote - cached daily so it only fetches once per day
    private fun loadDailyZenQuote() {
        val prefs = getSharedPreferences("zen_quote", MODE_PRIVATE)
        val savedDay = prefs.getInt("day_of_year", -1)
        val today = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)

        val tvQuote = findViewById<TextView>(R.id.tvZenQuote)
        val tvAuthor = findViewById<TextView>(R.id.tvZenAuthor)

        // use saved quote if already from today
        if (savedDay == today) {
            tvQuote.text = prefs.getString("quote", "stay focused 🌱")
            tvAuthor.text = prefs.getString("author", "")
            return
        }

        // fetch new quote in a background thread
        Thread {
            try {
                val client = OkHttpClient()
                val request = Request.Builder()
                    .url("https://zenquotes.io/api/random")
                    .build()

                val response = client.newCall(request).execute()
                val body = response.body?.string()

                val json = JSONArray(body)
                val quote = json.getJSONObject(0).getString("q")
                val author = json.getJSONObject(0).getString("a")


            } catch (e: Exception) {
                // backup message if fetching fails
                runOnUiThread {
                    tvQuote.text = "be present. be mindful. 🌿"
                    tvAuthor.text = ""
                }
            }
        }.start()
    }

    //   reminder handling (saving + showing + scheduling)
    private fun openReminderTimePicker(tvReminderTime: TextView) {
        val now = Calendar.getInstance()
        val hour = now.get(Calendar.HOUR_OF_DAY)
        val minute = now.get(Calendar.MINUTE)

        TimePickerDialog(
            this,
            { _, h, m ->
                saveReminderTime(h, m)
                scheduleDailyReminder(h, m)
                tvReminderTime.text = "reminder set for %02d:%02d".format(h, m)
            },
            hour, minute, true
        ).show()
    }

    private fun saveReminderTime(hour: Int, minute: Int) {
        val prefs = getSharedPreferences("reminder_prefs", MODE_PRIVATE)
        prefs.edit().putInt("hour", hour).putInt("minute", minute).apply()
    }

    private fun loadReminderTime(tvReminderTime: TextView) {
        val prefs = getSharedPreferences("reminder_prefs", MODE_PRIVATE)
        val hour = prefs.getInt("hour", -1)
        val minute = prefs.getInt("minute", -1)

        // show saved reminder time or fallback message
        if (hour == -1) {
            tvReminderTime.text = "no reminder set"
        } else {
            tvReminderTime.text = "reminder set for %02d:%02d".format(hour, minute)
        }
    }

    private fun scheduleDailyReminder(hour: Int, minute: Int) {

        val alarmManager = getSystemService(AlarmManager::class.java)

        val intent = Intent(this, ReminderReceiver::class.java).apply {
            action = ReminderReceiver.ACTION_REMINDER
        }

        val pending = PendingIntent.getBroadcast(
            this,
            1001,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)

            // schedule for tomorrow if time has already passed today
            if (timeInMillis < System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        alarmManager.setExactAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            calendar.timeInMillis,
            pending
        )

    }
}
