package com.example.atomicapp


import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.atomicapp.ui.home.Habit
import com.example.atomicapp.ui.home.HabitAdapter
import com.example.atomicapp.ui.history.HistoryActivity
import com.example.atomicapp.ui.progress.ProgressActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.text.SimpleDateFormat
import java.util.*
import com.example.atomicapp.user.getCurrentUserName

class MainActivity : AppCompatActivity() {


    private lateinit var rvHabits: RecyclerView
    private lateinit var fabAddHabit: FloatingActionButton
    private lateinit var tvGreeting: TextView
    private lateinit var tvTodayDate: TextView
    private lateinit var tvStreak: TextView

    // Storage
    private val gson = Gson()
    private val prefs by lazy {
        val user = getCurrentUserName()
        getSharedPreferences("habits_$user", Context.MODE_PRIVATE)
    }

    // Data
    private val habits = mutableListOf<Habit>()
    private lateinit var adapter: HabitAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.Theme_AtomicApp)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 1) Bind views
        rvHabits = findViewById(R.id.rvHabits)
        fabAddHabit = findViewById(R.id.fabAddHabit)
        tvGreeting = findViewById(R.id.tvGreeting)
        tvTodayDate = findViewById(R.id.tvTodayDate)
        tvStreak = findViewById(R.id.tvStreak)

        // 2) Header text
        setupHeader()

        // 3) Load habits from SharedPreferences (safe)
        loadHabitsSafe()

        // 4) Simple "new day" reset
        resetHabitsForNewDay()

        // 5) Setup list + adapter
        adapter = HabitAdapter(
            habits,
            onHabitChanged = {
                saveHabits()
                updateStreakLabel()
                saveCompletedHabitToHistory()
            },

            onHabitDeleted = {
                saveHabits()
                updateStreakLabel()
            }
        )
        rvHabits.layoutManager = LinearLayoutManager(this)
        rvHabits.adapter = adapter

        // 6) Initial streak text
        updateStreakLabel()

        // 7) Add habit button
        fabAddHabit.setOnClickListener {
            showAddHabitDialog()
        }

        // 8) Bottom navigation
        setupBottomNav()
    }

    // ---------------- HEADER ----------------
    private fun setupHeader() {
        tvGreeting.text = "Hi there 🌿"
        val dateFormat = SimpleDateFormat("EEEE, d MMM", Locale.getDefault())
        tvTodayDate.text = dateFormat.format(Date())
    }

    private fun saveCompletedHabitToHistory() {
        val user = getCurrentUserName()
        val historyPrefs = getSharedPreferences("history_$user", MODE_PRIVATE)

        val today = SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date())
        val completedHabits = habits.filter { it.doneToday }.map { it.name }

        historyPrefs.edit()
            .putStringSet(today, completedHabits.toSet())
            .apply()
    }


    // ---------------- LOAD / SAVE ----------------
    private fun loadHabitsSafe() {
        try {
            val json = prefs.getString("habit_list", null) ?: return
            val type = object : TypeToken<MutableList<Habit>>() {}.type
            val loaded: MutableList<Habit> = gson.fromJson(json, type)

            habits.clear()
            habits.addAll(loaded)
        } catch (e: Exception) {
            e.printStackTrace()
            habits.clear()
            prefs.edit().remove("habit_list").apply()
        }
    }

    private fun saveHabits() {
        val json = gson.toJson(habits)
        prefs.edit().putString("habit_list", json).apply()
    }

    // ---------------- NEW DAY RESET ----------------
    private fun resetHabitsForNewDay() {
        val today = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        val lastOpen = prefs.getInt("last_open_day", -1)

        if (lastOpen == today) return

        // New day: uncheck all, maybe break streaks
        habits.forEach { habit ->
            val lastDone = habit.lastCompletedDayOfYear
            habit.doneToday = false

            // If missed yesterday => break streak
            if (lastDone != -1 && lastDone < today - 1) {
                habit.streak = 0
            }
        }

        prefs.edit().putInt("last_open_day", today).apply()
        saveHabits()
    }

    private fun updateStreakLabel() {
        val bestStreak = habits.maxOfOrNull { it.streak } ?: 0
        tvStreak.text = if (bestStreak > 0) {
            "🔥 $bestStreak-day streak"
        } else {
            "No streak yet"
        }
    }

    // ---------------- ADD HABIT POPUP ----------------
    private fun showAddHabitDialog() {
        val view = LayoutInflater.from(this)
            .inflate(R.layout.dialog_add_habit, null)

        val etName = view.findViewById<EditText>(R.id.etHabitName)
        val spinner = view.findViewById<Spinner>(R.id.spinnerCategory)

        // Categories in dropdown
        val categories = listOf("Eco", "Health", "Productivity", "Mindfulness")
        val catAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            categories
        )
        spinner.adapter = catAdapter

        AlertDialog.Builder(this)
            .setTitle("Add Habit")
            .setView(view)
            .setPositiveButton("Save") { _, _ ->
                val name = etName.text.toString().trim()
                val category = spinner.selectedItem?.toString() ?: "General"

                if (name.isNotEmpty()) {
                    val habit = Habit(name, category)
                    habits.add(habit)
                    adapter.notifyItemInserted(habits.size - 1)
                    saveHabits()
                    updateStreakLabel()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------------- BOTTOM NAV ----------------
    private fun setupBottomNav() {
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavMain)
        bottomNav.selectedItemId = R.id.nav_home

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home -> true

                R.id.nav_progress -> {
                    startActivity(Intent(this, ProgressActivity::class.java))
                    true
                }

                R.id.nav_history -> {
                    startActivity(Intent(this, HistoryActivity::class.java))
                    true
                }

                else -> false
            }
        }
    }
}
