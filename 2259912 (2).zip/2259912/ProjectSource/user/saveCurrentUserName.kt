package com.example.atomicapp.user

import android.content.Context

fun Context.saveCurrentUserName(name: String) {
    val prefs = getSharedPreferences("user_session", Context.MODE_PRIVATE)
    prefs.edit().putString("current_user", name).apply()
}
