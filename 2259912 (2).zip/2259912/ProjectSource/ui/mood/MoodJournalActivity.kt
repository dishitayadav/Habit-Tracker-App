package com.example.atomicapp.ui.mood

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.atomicapp.R
import com.example.atomicapp.ui.history.saveToHistory

class MoodJournalActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.Theme_AtomicApp)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mood_journal)

        val moodGroup = findViewById<RadioGroup>(R.id.moodGroup)
        val moodHappy = findViewById<RadioButton>(R.id.moodHappy)
        val moodNeutral = findViewById<RadioButton>(R.id.moodNeutral)
        val moodSad = findViewById<RadioButton>(R.id.moodSad)
        val etReflection = findViewById<EditText>(R.id.etReflection)
        val btnSave = findViewById<Button>(R.id.btnSaveMood)

        btnSave.setOnClickListener {
            val selectedMood = when {
                moodHappy.isChecked -> "🙂 Happy"
                moodNeutral.isChecked -> "😐 Neutral"
                moodSad.isChecked -> "☹️ Sad"
                else -> "Unknown"
            }

            val note = etReflection.text.toString()
            val entry = "Mood: $selectedMood • Note: $note"

            saveToHistory(this, entry)

            finish()
        }
    }
}
