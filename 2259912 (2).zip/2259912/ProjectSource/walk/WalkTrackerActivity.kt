// used a lot of google + external examples to help figure out maps + location stuff for this

package com.example.atomicapp.walk

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.example.atomicapp.R
import com.example.atomicapp.ui.history.saveToHistory
import com.google.android.gms.location.*
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.PolylineOptions
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.snackbar.Snackbar
import kotlin.math.roundToInt

class WalkTrackerActivity : AppCompatActivity() {

    private lateinit var map: GoogleMap
    private lateinit var fusedLocation: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback

    private var walking = false
    private var distanceMeters = 0.0
    private val routePoints = mutableListOf<LatLng>()

    private lateinit var btnStart: MaterialButton
    private lateinit var btnStop: MaterialButton
    private lateinit var btnBack: MaterialButton
    private lateinit var cardStats: MaterialCardView

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.Theme_AtomicApp)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_walk_tracker)

        // ui bindings
        btnStart = findViewById(R.id.btnStartWalk)
        btnStop = findViewById(R.id.btnStopWalk)
        btnBack = findViewById(R.id.btnBackHome)
        cardStats = findViewById(R.id.cardStats)

        btnBack.setOnClickListener { finish() }

        fusedLocation = LocationServices.getFusedLocationProviderClient(this)

        // map setup
        val mapFragment = supportFragmentManager.findFragmentById(R.id.mapWalk) as SupportMapFragment
        mapFragment.getMapAsync { googleMap ->
            map = googleMap
            map.uiSettings.isZoomControlsEnabled = true
            enableLocation()
        }

        // button actions
        btnStart.setOnClickListener { startWalk() }
        btnStop.setOnClickListener { stopWalk() }
    }

    // location permission
    private fun enableLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                2001
            )
            return
        }
        map.isMyLocationEnabled = true
    }

    // start walk tracking

    private fun startWalk() {
        walking = true
        distanceMeters = 0.0
        routePoints.clear()
        cardStats.visibility = View.GONE

        Snackbar.make(btnStart, "walk started 🚶‍♀️", Snackbar.LENGTH_SHORT).show()

        val request = LocationRequest.Builder(
            Priority.PRIORITY_HIGH_ACCURACY,
            1500L // roughly every 1.5 seconds
        ).setMinUpdateDistanceMeters(1f)
            .build()

        // callback whenever new gps locations come in
        locationCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                if (!walking) return
                for (loc in result.locations) addPoint(loc)
            }
        }

        fusedLocation.requestLocationUpdates(request, locationCallback, mainLooper)
    }

    // add a gps point + draw path + update distance
    private fun addPoint(location: Location) {
        val point = LatLng(location.latitude, location.longitude)
        routePoints.add(point)

        // calculate distance from previous point
        if (routePoints.size > 1) {
            val prev = routePoints[routePoints.size - 2]
            val results = FloatArray(1)
            Location.distanceBetween(
                prev.latitude, prev.longitude,
                point.latitude, point.longitude,
                results
            )
            distanceMeters += results[0]
        }

        // draw green path line on the map
        map.addPolyline(
            PolylineOptions()
                .addAll(routePoints)
                .width(10f)
                .color(resources.getColor(R.color.atomic_dark_green, theme))
        )

        // smoothly follow the user's movement
        map.animateCamera(CameraUpdateFactory.newLatLngZoom(point, 18f))
    }

    // stop walk and show summary stats
    private fun stopWalk() {
        walking = false
        fusedLocation.removeLocationUpdates(locationCallback)

        val km = distanceMeters / 1000
        val calories = (km * 50).roundToInt()
        val co2 = (km * 150).roundToInt()

        // save a history entry for today
        saveToHistory(
            this,
            "Walked ${String.format("%.2f", km)} km • $calories kcal • $co2 g CO₂ saved"
        )

        cardStats.visibility = View.VISIBLE

        findViewById<TextView>(R.id.tvStatsDistance).text =
            "distance: ${String.format("%.2f", km)} km"

        findViewById<TextView>(R.id.tvStatsCalories).text =
            "calories: $calories kcal"

        findViewById<TextView>(R.id.tvStatsCO2).text =
            "co₂ saved: $co2 g"
    }
}
