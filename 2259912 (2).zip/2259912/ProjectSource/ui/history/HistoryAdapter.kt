package com.example.atomicapp.ui.history

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.atomicapp.R

class HistoryAdapter(private val items: List<HistoryItem>) :
    RecyclerView.Adapter<HistoryAdapter.HistoryViewHolder>() {

    // holds references to the views in each list item
    class HistoryViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val Date: TextView = view.findViewById(R.id.tvHistoryDate)
        val Details : TextView = view.findViewById(R.id.tvHistoryDetails)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoryViewHolder {
        // inflate the layout for each history item
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_history, parent, false)
        return HistoryViewHolder(view)
    }

    override fun onBindViewHolder(holder:  HistoryViewHolder,position: Int) {
        // bind the data to the textviews
        val item = items[position]
        holder.Date.text = item.date
        holder.Details.text = item.details
    }

    override fun getItemCount(): Int = items.size  // total number of items
}
