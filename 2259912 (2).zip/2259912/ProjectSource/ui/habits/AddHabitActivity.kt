package com.example.atomicapp.ui.habits

import android.app.Activity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.atomicapp.R
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton

class AddHabitActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_habit)

        // toolbar back button
        val toolbar = findViewById<MaterialToolbar>(R.id.topAppBar)
        toolbar.setNavigationOnClickListener { finish() }

        // ui inputs
        val etName = findViewById<EditText>(R.id.etHabitName)
        val categoryDropdown = findViewById<AutoCompleteTextView>(R.id.actCategory)
        val btnSave = findViewById<MaterialButton>(R.id.btnSaveHabit)

        // dropdown categories shown in the autocomplete
        val categories = listOf("health", "eco", "productivity", "mindfulness")

        categoryDropdown.setAdapter(
            ArrayAdapter(this, android.R.layout.simple_list_item_1, categories)
        )

        btnSave.setOnClickListener {
            val name = etName.text.toString().trim()
            val category = categoryDropdown.text.toString().trim()

            // basic form validation
            if (name.isEmpty() || category.isEmpty()) {
                Toast.makeText(this, "please fill everything", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // returning the new habit data back to main activity
            intent.putExtra("NEW_HABIT_NAME", name)
            intent.putExtra("NEW_HABIT_CATEGORY", category)
            setResult(Activity.RESULT_OK, intent)

            finish()
        }
    }
}
