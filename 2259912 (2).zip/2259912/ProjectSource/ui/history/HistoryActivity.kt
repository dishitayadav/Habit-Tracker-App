package com.example.atomicapp.ui.history

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.atomicapp.R
import com.example.atomicapp.ui.dashboard.DashboardActivity
import com.example.atomicapp.ui.progress.ProgressActivity
import com.example.atomicapp.user.getCurrentUserName
import com.google.android.material.bottomnavigation.BottomNavigationView

class HistoryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.Theme_AtomicApp)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        val rv = findViewById<RecyclerView>(R.id.rvHistory)
        val username = getCurrentUserName()
        val preference = getSharedPreferences("history_$username", MODE_PRIVATE)

        // converting sharedpreferences data to list of historyitems
        val items = preference.all.map { (date, value) ->
            val list = (value as? Set<String>)?.toList() ?: emptyList()

            HistoryItem(
                date = date,
                details = list.joinToString("\n")
            )
        }.sortedByDescending { it.date }  // newest first

        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = HistoryAdapter(items)

        setupBottomNav()
    }


    private fun setupBottomNav() {
        val bottom = findViewById<BottomNavigationView>(R.id.bottomNavHistory)
        bottom.selectedItemId = R.id.nav_history

        bottom.setOnItemSelectedListener { item ->
            when (item.itemId) {

                R.id.nav_home -> {
                    // go back to dashboard
                    startActivity(Intent(this, DashboardActivity::class.java))
                    true
                }
                R.id.nav_progress -> {
                    // open progress screen
                    startActivity(Intent(this, ProgressActivity::class.java))
                    true

                }

                else -> true
            }
        }
    }
}
