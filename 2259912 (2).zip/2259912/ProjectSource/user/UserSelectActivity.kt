package com.example.atomicapp.user

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import com.example.atomicapp.R
import com.example.atomicapp.ui.dashboard.DashboardActivity
import com.google.android.material.button.MaterialButton

class UserSelectActivity : AppCompatActivity() {

    private lateinit var listUsers: ListView
    private lateinit var newUser1: EditText
    private lateinit var addUserButton: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.Theme_AtomicApp)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_select)

        // linking views
        listUsers = findViewById(R.id.listUsers)
        newUser1 = findViewById(R.id.etNewUser)
        addUserButton = findViewById(R.id.btnAddUser)

        // load any saved users when entering this screen
        loadUsers()

        addUserButton.setOnClickListener {
            val name = newUser1.text.toString().trim()

            // basic name validation
            if (name.isNotEmpty()) {
                saveUser(name)
                newUser1.text.clear()
                loadUsers()  // refresh list
            }
        }

        // when user taps a name → save that as current user + go to dashboard
        listUsers.setOnItemClickListener { _, _, position, _ ->
            val prefs = getSharedPreferences("users", MODE_PRIVATE)
            val savedSet = prefs.getStringSet("user_list", setOf("Guest"))!!.toList()
            val selectedName = savedSet[position]

            // remember chosen user for rest of the app
            prefs.edit().putString("current_user", selectedName).apply()

            startActivity(Intent(this, DashboardActivity::class.java))
            finish()
        }
    }

    // saves a new username to shared preferences
    private fun saveUser(username: String) {
        val prefs = getSharedPreferences("users", MODE_PRIVATE)
        val set = prefs.getStringSet("user_list", mutableSetOf())!!.toMutableSet()
        set.add(username)
        prefs.edit().putStringSet("user_list", set).apply()
    }

    // loads all usernames and shows them in the listview
    private fun loadUsers() {
        val prefs = getSharedPreferences("users", MODE_PRIVATE)
        val userList = prefs.getStringSet("user_list", setOf("Guest"))!!.toList()

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            userList
        )

        listUsers.adapter = adapter
    }
}
