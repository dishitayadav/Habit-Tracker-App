package com.example.atomicapp.ui.history

import android.content.Context
import com.example.atomicapp.user.getCurrentUserName
import java.text.SimpleDateFormat
import java.util.*

fun saveToHistory(context: Context, entry: String) {
    val username = context.getCurrentUserName()
    val prefs = context.getSharedPreferences("history_$username", Context.MODE_PRIVATE)

    val today = SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date())

    val set = prefs.getStringSet(today, emptySet())!!.toMutableSet()
    set.add(entry)

    prefs.edit().putStringSet(today, set).apply()
}
