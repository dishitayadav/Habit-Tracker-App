package com.example.atomicapp.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.atomicapp.MainActivity
import java.util.Calendar

// BroadcastReceiver handles the reminder logic for the app
class ReminderReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_REMINDER = "atomicapp.ACTION_REMINDER"
        const val ACTION_DONE = "atomicapp.ACTION_DONE"
        const val ACTION_SNOOZE = "atomicapp.ACTION_SNOOZE"
    }

    override fun onReceive(context: Context, intent: Intent?) {
        // helper class for building and showing notifications
        val notificationHelper = NotificationHelper(context)

        when (intent?.action) {

            ACTION_DONE -> {
                increaseStats(context)



                val doneNotification = notificationHelper.buildReminderNotification(
                    "Nice work ✨",
                    "You completed your habit today.",
                    PendingIntent.getActivity(
                        context,
                        2001,
                        Intent(context, MainActivity::class.java),
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    ),
                    PendingIntent.getBroadcast(
                        context,
                        2002,
                        Intent(context, ReminderReceiver::class.java).apply { action = ACTION_DONE },
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    ),
                    PendingIntent.getBroadcast(
                        context,
                        2003,
                        Intent(context, ReminderReceiver::class.java).apply { action = ACTION_SNOOZE },
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )
                )

                notificationHelper.notify(999, doneNotification)
                return
            }

            // user tapped snooze
            ACTION_SNOOZE -> {
                snooze10Minutes(context)
                return
            }

            // default: fire the normal reminder and re-schedule for tomorrow
            else -> {
                showMainReminder(context, notificationHelper)
                rescheduleTomorrow(context)
            }
        }
    }

    // buidls and shows the main reminder notification for the current habit
    private fun showMainReminder(context: Context, helper: NotificationHelper) {
        val prefs = context.getSharedPreferences("reminder_prefs", Context.MODE_PRIVATE)

        val habit = prefs.getString("primary_habit", "your habit")
        val message = "Time to do: $habit"

        // PendingIntent to open the app when the notification is tapped
        val openIntent = Intent(context, MainActivity::class.java)
        val openPending = PendingIntent.getActivity(
            context,
            2001,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // PendingIntent for "mark done" button
        val donePending = PendingIntent.getBroadcast(
            context,
            2002,
            Intent(context, ReminderReceiver::class.java).apply { action = ACTION_DONE },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // PendingIntent for "snooze 10 min" button
        val snoozePending = PendingIntent.getBroadcast(
            context,
            2003,
            Intent(context, ReminderReceiver::class.java).apply { action = ACTION_SNOOZE },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notificationBuilder = helper.buildReminderNotification(
            "Habit reminder 🌿",
            message,
            openPending,
            donePending,
            snoozePending
        )

        helper.notify(999, notificationBuilder)
    }

    //  simple "stats" system: track how many times the user completed a habit each day
    private fun increaseStats(context: Context) {
        val stats = context.getSharedPreferences("atomic_stats", Context.MODE_PRIVATE)
        val today = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        val key = "day_$today"

        // increment the counter for today
        val newCount = stats.getInt(key, 0) + 1
        stats.edit()
            .putInt(key, newCount)
            .apply()
    }

    // schedule the reminder again in 10 minutes
    private fun snooze10Minutes(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        val snoozeTimeMillis = Calendar.getInstance().apply {
            add(Calendar.MINUTE, 10)
        }.timeInMillis

        val intent = Intent(context, ReminderReceiver::class.java).apply {
            action = ACTION_REMINDER
        }

        val pending = PendingIntent.getBroadcast(
            context,
            1001,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // setExactAndAllowWhileIdle so it works even in doze mode
        alarmManager.setExactAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            snoozeTimeMillis,
            pending
        )
    }

    // re-schedule the reminder for the same time tomorrow
    private fun rescheduleTomorrow(context: Context) {
        val prefs = context.getSharedPreferences("reminder_prefs", Context.MODE_PRIVATE)
        val hour = prefs.getInt("hour", 9)      // default: 9am
        val minute = prefs.getInt("minute", 0)  // default: 00

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        val triggerAtMillis = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, 1)
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        val intent = Intent(context, ReminderReceiver::class.java).apply {
            action = ACTION_REMINDER
        }

        val pending = PendingIntent.getBroadcast(
            context,
            1001,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        alarmManager.setExactAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            triggerAtMillis,
            pending
        )
    }
}
