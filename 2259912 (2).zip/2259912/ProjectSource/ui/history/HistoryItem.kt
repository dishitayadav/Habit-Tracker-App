package com.example.atomicapp.ui.history

data class HistoryItem(
    val date: String,
    val details: String
)
