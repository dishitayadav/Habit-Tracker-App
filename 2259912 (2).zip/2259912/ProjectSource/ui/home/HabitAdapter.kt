package com.example.atomicapp.ui.home

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.atomicapp.R
import com.example.atomicapp.ui.history.saveToHistory
import java.util.*

class HabitAdapter(
    private val habits: MutableList<Habit>,
    private val onHabitChanged: () -> Unit,
    private val onHabitDeleted: () -> Unit) :
    RecyclerView.Adapter<HabitAdapter.HabitViewHolder>() {

    // viewholder holds references to all the views in each habit card
    inner class HabitViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tvHabitName)
        val tvCategory: TextView = view.findViewById(R.id.tvHabitCategory)
        val tvProgress: TextView = view.findViewById(R.id.tvHabitProgress)
        val btnDelete: ImageButton = view.findViewById(R.id.btnDeleteHabit)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HabitViewHolder {
        // inflate the layout for each habit item
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_habit, parent, false)
        return HabitViewHolder(view)
    }

    override fun onBindViewHolder(holder: HabitViewHolder, position: Int) {
        val habit = habits[position]
        val context = holder.itemView.context

        // set basic text info
        holder.tvName.text = habit.name
        holder.tvCategory.text = habit.category

        // show if user already did the habit today
        holder.tvProgress.text =
            if (habit.doneToday) "completed ✔" else "not done"

        // tapping the whole item toggles completion
        holder.itemView.setOnClickListener {
            habit.doneToday = !habit.doneToday

            if (habit.doneToday) {
                // increase streak and save a quick history log
                habit.streak += 1
                habit.lastCompletedDayOfYear =
                    Calendar.getInstance().get(Calendar.DAY_OF_YEAR)

                saveToHistory(context, "completed habit: ${habit.name}")
            }

            notifyItemChanged(position)
            onHabitChanged()  // update ui stats on dashboard
        }

        // delete habit
        holder.btnDelete.setOnClickListener {
            habits.removeAt(position)
            notifyItemRemoved(position)
            onHabitDeleted()  // callback to update storage
        }
    }

    override fun getItemCount(): Int = habits.size
}
