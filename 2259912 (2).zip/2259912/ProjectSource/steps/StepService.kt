package com.example.atomicapp.steps

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.atomicapp.R
import java.util.Calendar

class StepService : Service(), SensorEventListener {

    companion object {
        const val channelID = "atomicapp.steps"
        const val notificationID = 200
        private const val prefs = "step_prefs"
        private const val baseline = "baseline_steps"
        private const val todaySteps = "today_steps"
        private const val dayYear = "day_of_year"
    }

    private var sensorManager: SensorManager? = null
    private var stepSensor: Sensor? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()

        // getting the sensor manager + the step counter sensor
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        stepSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)

        // need a foreground notification to keep the service alive
        createChannel()
        startForeground(notificationID, buildNotification("tracking steps…").build())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // start listening to step updates when the service starts
        stepSensor?.also {
            sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        // stop listening when service is killed
        sensorManager?.unregisterListener(this)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
    }

    override fun onSensorChanged(event: SensorEvent?) {

        // making sure we only handle step counter events
        if (event?.sensor?.type != Sensor.TYPE_STEP_COUNTER) return

        val prefs = getSharedPreferences(prefs, Context.MODE_PRIVATE)
        val totalStepsFromBoot = event.values[0].toLong()

        val calendar = Calendar.getInstance()
        val today = calendar.get(Calendar.DAY_OF_YEAR)
        val storedDay = prefs.getInt(dayYear, -1)

        val baseline: Long
        val todaySteps: Long

        if (storedDay != today) {
            // new day → reset the baseline and today's count
            baseline = totalStepsFromBoot
            todaySteps = 0
            prefs.edit()
                .putLong(Companion.baseline, baseline)
                .putLong(Companion.todaySteps, todaySteps)
                .putInt(dayYear, today)
                .apply()
        } else {
            // same day → calculate steps since baseline
            baseline = prefs.getLong(Companion.baseline, totalStepsFromBoot)
            todaySteps = totalStepsFromBoot - baseline

            prefs.edit()
                .putLong(Companion.todaySteps, todaySteps)
                .apply()
        }

        // update foreground notification with current step count
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(notificationID, buildNotification("steps today: $todaySteps").build())
    }

    private fun createChannel() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelID,
                "step tracking",
                NotificationManager.IMPORTANCE_LOW
            )

            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): NotificationCompat.Builder {
        // simple persistent notification for the foreground service
        return NotificationCompat.Builder(this, channelID)
            .setContentTitle("step tracker running")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setOngoing(true)
    }
}
