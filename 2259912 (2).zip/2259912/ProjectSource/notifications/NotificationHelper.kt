package com.example.atomicapp.notifications

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Color
import android.media.AudioAttributes
import android.net.Uri
import androidx.core.app.NotificationCompat
import com.example.atomicapp.R

// notif helper class (used for creating the reminder notifications)
// followed the Android docs + lecture slides
class NotificationHelper(base: Context) : ContextWrapper(base) {

    companion object {
        const val CHANNEL_ID = "atomicapp.reminders"
        const val CHANNEL_NAME = "Habit Reminders"
    }

    //  store the manager so we don't keep getting it every time
    private var notificationManager: NotificationManager? = null

    // getter for the notification manager
    private val manager: NotificationManager
        get() {
            if (notificationManager == null) {
                notificationManager =
                    getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            }
            return notificationManager!!
        }

    init {
        // channel must be created before posting notifications
        createChannel()
    }

    private fun createChannel() {
        // custom iphone sound for the reminder (stored in res/raw)
        val soundUri = Uri.parse("android.resource://$packageName/raw/alarm_sound")

        // setting audio attributes so Android knows how to treat the sound
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM) // alarm-type behavior
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        // i set it to high importance so the reminder shows up prominently
        val channel = NotificationChannel(
            CHANNEL_ID,
            CHANNEL_NAME,
            NotificationManager.IMPORTANCE_HIGH
        )

        // visual +vibration settings
        channel.enableLights(true)
        channel.lightColor = Color.GREEN
        channel.enableVibration(true)
        channel.vibrationPattern = longArrayOf(0, 300, 200, 300)
        channel.setSound(soundUri, audioAttributes)

        // sjow full content on lock screen
        channel.lockscreenVisibility = Notification.VISIBILITY_PUBLIC

        // Register channel with the system
        manager.createNotificationChannel(channel)
    }

    // builds the notification for a reminder
    fun buildReminderNotification(
        title: String,
        message: String,
        contentIntent: PendingIntent,
        doneIntent: PendingIntent,
        snoozeIntent: PendingIntent
    ): NotificationCompat.Builder {

        // bigText so longer habit descriptions show fully
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_bell) // simple bell icon in drawable
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setContentIntent(contentIntent)
            .addAction(0, "Mark done", doneIntent)      // action button
            .addAction(0, "Snooze 10 min", snoozeIntent) // another action button
            .setAutoCancel(false)
            .setOngoing(true) // keeps the reminder active until user interacts
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
    }

    // sends the notification to the system
    fun notify(id: Int, builder: NotificationCompat.Builder) {
        val notification = builder.build()
        notification.flags = notification.flags or Notification.FLAG_ONGOING_EVENT
        manager.notify(id, notification)
    }
}
