package com.example.atomicapp.ui.steps

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.atomicapp.R
import com.example.atomicapp.ui.dashboard.DashboardActivity
import com.google.android.material.appbar.MaterialToolbar

class StepTrackerActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var tvSteps: TextView
    private var sensorManager: SensorManager? = null
    private var totalSteps = 0f
    private var previousTotalSteps = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_step_tracker)

        tvSteps = findViewById(R.id.tvStepsToday)

        // top app bar back button
        val toolbar = findViewById<MaterialToolbar>(R.id.topAppBarSteps)
        toolbar.setNavigationOnClickListener {
            startActivity(Intent(this, DashboardActivity::class.java))
            finish()
        }

        // asking for activity recognition permission (needed for step counting)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACTIVITY_RECOGNITION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACTIVITY_RECOGNITION),
                1001
            )
        }

        // getting the sensor manager + step counter sensor
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        val stepSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)

        if (stepSensor == null) {
            // phone doesn't have a step counter sensor
            tvSteps.text = "step sensor not available on device"
        } else {
            // start listening to step updates (not sure if this works)
            sensorManager?.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        // update step count whenever the sensor reports a change
        if (event != null) {
            totalSteps = event.values[0]
            val stepsToday = (totalSteps - previousTotalSteps).toInt()
            tvSteps.text = stepsToday.toString()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
    }

    override fun onPause() {
        super.onPause()
        // stop listening when leaving the activity
        sensorManager?.unregisterListener(this)
    }
}
