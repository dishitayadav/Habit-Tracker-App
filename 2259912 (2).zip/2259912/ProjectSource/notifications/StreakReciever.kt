package com.example.atomicapp.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.atomicapp.MainActivity
import java.util.Calendar

// reciever that checks whether the user completed any habits yesterday. if not, it shows a gentle reminder so they stay aware of their streak.
//  runs every morning (scheduled by AlarmManager).
class StreakReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        // Just making sure the broadcast is the one we expect
        if (intent?.action == "atomicapp.ACTION_STREAK_CHECK") {
            checkStreak(context)
            scheduleNextDay(context)  // keep the check recurring
        }
    }

    // checks if yesterday had any completed habits.
    // if not send notif
    private fun checkStreak(context: Context) {
        val prefs = context.getSharedPreferences("atomic_stats", Context.MODE_PRIVATE)

        // get yesterday's date
        val cal = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, -1)
        }
        val yesterday = cal.get(Calendar.DAY_OF_YEAR)

        // count how many habits the user completed yesterday
        val completed = prefs.getInt("day_$yesterday", 0)

        // if > 0, then their streak is fine and we don't need to notify them
        if (completed > 0) {
            Log.d("STREAK", "Yesterday OK: $completed habits")
            return
        }

        val helper = NotificationHelper(context)

        // if user taps the notification, open the main activity
        val openIntent = Intent(context, MainActivity::class.java)
        val openPending = PendingIntent.getActivity(
            context,
            4001,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // dummy pending intent for "done" and "snooze" actions
        val dummy = PendingIntent.getBroadcast(
            context,
            4002,
            Intent(), // added because error if not here
            PendingIntent.FLAG_IMMUTABLE
        )

        val notif = helper.buildReminderNotification(
            "Don't break your streak!",
            "You didn't complete a habit yesterday. Today is a fresh start 💪",
            openPending,
            dummy,
            dummy
        )

        // use a different ID so this notification doesn't conflict with the regular reminder
        helper.notify(777, notif)
    }

    private fun scheduleNextDay(context: Context) {
        scheduleDaily(context, 9, 0)
    }

    companion object {
        // sets a repeating alarm that triggers this receiver everyday at a specific time
        fun scheduleDaily(context: Context, hour: Int, minute: Int) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

            // broadcast that will trigger the streak check
            val intent = Intent(context, StreakReceiver::class.java).apply {
                action = "atomicapp.ACTION_STREAK_CHECK"
            }

            val pending = PendingIntent.getBroadcast(
                context,
                4000,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)

                // if the time today has already passed, schedule it for tomorrow
                if (timeInMillis < System.currentTimeMillis()) {
                    add(Calendar.DAY_OF_YEAR, 1)
                }
            }

            alarmManager.setInexactRepeating(
                AlarmManager.RTC_WAKEUP,
                cal.timeInMillis,
                AlarmManager.INTERVAL_DAY,
                pending
            )

            Log.d("STREAK", "Daily streak check set for $hour:$minute")
        }
    }
}
