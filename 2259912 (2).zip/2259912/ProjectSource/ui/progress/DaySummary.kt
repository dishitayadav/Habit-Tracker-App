package com.example.atomicapp.ui.progress

data class DaySummary(
    val date: String,
    val habitsDone: Int,
    val distanceKm: Double,
    val calories: Int,
    val co2: Int
)
