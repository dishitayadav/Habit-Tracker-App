package com.example.atomicapp.ui.home

data class Habit(
    val name: String,
    val category: String,
    var doneToday: Boolean = false,
    var streak: Int = 0,
    var lastCompletedDayOfYear: Int = -1
)
