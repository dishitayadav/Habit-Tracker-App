package com.example.atomicapp.ui.progress

data class DayStat(
    val date: String,
    val completedHabits: Int,
    val mood: String,
    val note: String,
    val walkSummary: String,
    val co2Saved: Int
) {

    // converts emoji mood → a number we can graph (0–4)
    val moodValue: Int
        get() = when {
            mood.contains("😁") || mood.contains("😄") || mood.contains("😊") -> 4
            mood.contains("🙂") -> 3
            mood.contains("😐") -> 2
            mood.contains("☹️") || mood.contains("🙁") -> 1
            mood.contains("😢") || mood.contains("😭") -> 0
            else -> 2   // fallback neutral value
        }

    companion object {

        // builds a day stat object from raw history text entries
        fun fromHistory(date: String, items: List<String>): DayStat {

            val moodLine = items.find { it.startsWith("Mood:") } ?: "Mood: 😐 Neutral"
            val noteLine = items.find { it.startsWith("Note:") } ?: "Note: (none)"
            val walkLine = items.find { it.startsWith("Walked") } ?: "Walked 0 km"

            // get co2 saved from the walk line (e.g., “200 g saved”)
            val co2 = Regex("(\\d+) g").find(walkLine)?.groupValues?.get(1)?.toIntOrNull() ?: 0

            // count how many habits the user completed that day
            val completed = items.count { it.contains("Completed habit") }

            return DayStat(
                date = date,
                completedHabits = completed,
                mood = moodLine.replace("Mood:", "").trim(),
                note = noteLine.replace("Note:", "").trim(),
                walkSummary = walkLine.trim(),
                co2Saved = co2
            )
        }
    }
}
