package com.example.atomicapp.ui.progress

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.atomicapp.R
import com.example.atomicapp.ui.dashboard.DashboardActivity
import com.example.atomicapp.ui.history.HistoryActivity
import com.example.atomicapp.user.getCurrentUserName
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.components.XAxis
import com.google.android.material.bottomnavigation.BottomNavigationView

class ProgressActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.Theme_AtomicApp)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_progress)

        val tvEmpty = findViewById<TextView>(R.id.tvEmptyProgress)

        val chartMood = findViewById<LineChart>(R.id.chartMood)
        val chartCo2 = findViewById<BarChart>(R.id.chartCo2)

        val username = getCurrentUserName()
        val prefs = getSharedPreferences("history_$username", MODE_PRIVATE)

        // if user has no history data yet → show placeholder text
        if (prefs.all.isEmpty()) {
            tvEmpty.visibility = View.VISIBLE
            return
        }

        // convert shared prefs entries → list of day stat objects
        val items: List<DayStat> = prefs.all.map { (date, value) ->
            DayStat.fromHistory(date, (value as Set<String>).toList())
        }.sortedBy { it.date }  // sort oldest → newest for chart display

        tvEmpty.visibility = View.GONE

        // set up the two charts with the processed data
        setupMoodChart(chartMood, items)
        setupCO2Chart(chartCo2, items)

        setupBottomNav()
    }

    // mood line chart (shows general emotional trend)
    private fun setupMoodChart(chart: LineChart, days: List<DayStat>) {
        val entries = days.mapIndexed { index, day ->
            Entry(index.toFloat(), day.moodValue.toFloat())
        }

        val dataSet = LineDataSet(entries, "mood trend (0–4)").apply {
            lineWidth = 3f
            circleRadius = 5f
            setCircleColor(resources.getColor(R.color.atomic_dark_green, theme))
            color = resources.getColor(R.color.atomic_dark_green, theme)
            valueTextColor = resources.getColor(R.color.atomic_dark_green, theme)
        }

        chart.data = LineData(dataSet)
        chart.xAxis.position = XAxis.XAxisPosition.BOTTOM
        chart.axisRight.isEnabled = false
        chart.description.text = ""   // removing default description text
        chart.invalidate()            // refresh chart
    }

    // co₂ bar chart (based on user's walking activity)
    private fun setupCO2Chart(chart: BarChart, days: List<DayStat>) {
        val entries = days.mapIndexed { index, day ->
            BarEntry(index.toFloat(), day.co2Saved.toFloat())
        }

        val set = BarDataSet(entries, "co₂ saved (grams)").apply {
            color = resources.getColor(R.color.atomic_dark_green, theme)
            valueTextColor = resources.getColor(R.color.atomic_dark_green, theme)
        }

        chart.data = BarData(set)
        chart.axisRight.isEnabled = false
        chart.description.text = ""   // no default label
        chart.invalidate()
    }

    // bottom navigation bar
    private fun setupBottomNav() {
        val bottom = findViewById<BottomNavigationView>(R.id.bottomNavProgress)
        bottom.selectedItemId = R.id.nav_progress

        bottom.setOnItemSelectedListener { item ->
            when (item.itemId) {

                R.id.nav_home -> {
                    // go back to dashboard
                    startActivity(Intent(this, DashboardActivity::class.java))
                    true
                }

                R.id.nav_history -> {
                    // open habit history screen
                    startActivity(Intent(this, HistoryActivity::class.java))
                    true
                }

                else -> true
            }
        }
    }
}
