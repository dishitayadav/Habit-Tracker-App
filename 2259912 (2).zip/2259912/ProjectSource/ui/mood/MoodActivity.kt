package com.example.atomicapp.ui.mood

import android.os.Bundle
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.atomicapp.R
import com.example.atomicapp.user.getCurrentUserName
import com.google.android.material.button.MaterialButton
import java.text.SimpleDateFormat
import java.util.*

class MoodActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.Theme_AtomicApp)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mood)

        // ui elements
        val moodSeek = findViewById<SeekBar>(R.id.seekMood)
        val tvEmoji = findViewById<TextView>(R.id.tvMoodEmoji)
        val etNote = findViewById<EditText>(R.id.etMoodNote)
        val btnSave = findViewById<MaterialButton>(R.id.btnSaveMood)

        // simple list of emojis mapped to mood levels
        val emojis = listOf("😢", "🙁", "😐", "🙂", "😄")

        // seekbar goes from 0 → 4
        moodSeek.max = 4
        moodSeek.progress = 2

        // show the starting emoji
        tvEmoji.text = emojis[moodSeek.progress]

        // update emoji whenever user drags the slider
        moodSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, value: Int, fromUser: Boolean) {
                tvEmoji.text = emojis[value]
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        // save mood + optional note for user to fil
        btnSave.setOnClickListener {
            saveMood(emojis[moodSeek.progress], etNote.text.toString())
            finish()
        }
    }

    // saves mood data for the current user + date
    private fun saveMood(emoji: String, note: String) {
        val username = getCurrentUserName()
        val prefs = getSharedPreferences("mood_$username", MODE_PRIVATE)

        val date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

        prefs.edit()
            .putString("${date}_emoji", emoji)
            .putString("${date}_note", note)
            .apply()
    }
}
